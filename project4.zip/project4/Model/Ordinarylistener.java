package Model;

import javax.swing.undo.StateEditable;
import java.util.Set;

public class Ordinarylistener extends Listener{
    public Ordinarylistener(String userName, String password, String name, String email, int phoneNumber, int year, int month, int day) {
        super(userName, password, name, email, phoneNumber, year, month, day);
    }
}

