package Model;

import java.time.LocalDate;

public class Premiumlistener extends Listener{
        public Premiumlistener(String userName, String password, String name, String email, int phoneNumber, int year, int month, int day) {
            super(userName, password, name, email, phoneNumber, year, month, day);
        }

    @Override
    public void setNumberOfDaysLeft(int numberOfDaysLeft) {
        super.setNumberOfDaysLeft(numberOfDaysLeft);
    }

    @Override
    public int getNumberOfDaysLeft() {
        return super.getNumberOfDaysLeft();
    }
}

