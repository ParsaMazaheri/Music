package Model;

import java.util.ArrayList;

public class Podcaster extends Artist{
    ArrayList<Podcast> podcasts;
    public Podcaster(String userName, String password, String name, String email, int phoneNumber, int year, int month, int day) {
        super(userName, password,name, email, phoneNumber, year, month, day);
    }

    @Override
    public String getBio() {
        return super.getBio();
    }

    @Override
    public void setBio(String bio) {
        super.setBio(bio);
    }
}
