package Model;

public class Admin extends User{
        public Admin(String userName, String password, String name, String email, int phoneNumber, int year, int month, int day) {
            super(userName, password,name, email, phoneNumber, year, month, day);
        }

    @Override
    public String getRole() {
        return super.getRole();
    }

    @Override
    public void setRole(String role) {
        super.setRole(role);
    }
}
