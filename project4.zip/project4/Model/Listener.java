package Model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Listener extends User{
    private ArrayList<PlayList> playLists;
    private Map<Audio, Integer> played;
    private ArrayList<Artist> followed;
    private String genres;
    private LocalDate SED;
    private ArrayList<Genre> favoriteGenres;
    public int wallet = 10;
    public int numberOfDaysLeft = 0;


    public Listener(String userName, String password, String name, String email, int phoneNumber, int year, int month, int day) {
        super(userName, password,name, email, phoneNumber, year, month, day);
        ArrayList<PlayList> playLists = new ArrayList<PlayList>();
        Map<Audio, Integer> played = new HashMap<Audio, Integer>();
        ArrayList<Artist> followed = new ArrayList<Artist>();
    }

    public ArrayList<PlayList> getPlayLists() {
        return playLists;
    }

    public ArrayList<Artist> getFollowed() {
        return followed;
    }

    public ArrayList<Genre> getFavoriteGenres() {
        return favoriteGenres;
    }

    public void setWallet(int wallet) {
        this.wallet = wallet;
    }

    public String getGenres() {
        return genres;
    }
    public int getNumberOfDaysLeft() {
        return numberOfDaysLeft;
    }

    public int getWallet() {
        return wallet;
    }

    public LocalDate getSED() {
        return SED;
    }

    public Map<Audio, Integer> getPlayed() {
        return played;
    }

    public void setFollowed(ArrayList<Artist> followed) {
        this.followed = followed;
    }

    public void setFavoriteGenres(ArrayList<Genre> favoriteGenres) {
        this.favoriteGenres = favoriteGenres;
    }

    public void setGenres(String genres) {
        this.genres = genres;
    }

    public void setNumberOfDaysLeft(int numberOfDaysLeft) {
        this.numberOfDaysLeft = numberOfDaysLeft;
    }

    public void setPlayed(Map<Audio, Integer> played) {
        this.played = played;
    }

    public void setPlayLists(ArrayList<PlayList> playLists) {
        this.playLists = playLists;
    }

    public void setSED(LocalDate SED) {
        this.SED = SED;
    }

}
