package Model;

public class Music extends Audio {
    public Music(String model, String title,Genre genre,String lyric ,String link, String cover , int id){
        super(model,title,genre,lyric,link,cover,id);
    }
    @Override
    public String getTitle() {
        return super.getTitle();
    }

    @Override
    public void setTitle(String title) {
        super.setTitle(title);
    }
}
