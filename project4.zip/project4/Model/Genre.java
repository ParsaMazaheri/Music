package Model;

public enum Genre {
    Rock,
    Pop,
    Jazz,
    HipHop,
    Country,
    True_Crime,
    Society,
    Interview,
    History;
}
