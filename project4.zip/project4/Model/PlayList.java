package Model;

import java.util.ArrayList;

public class PlayList {
    private int id;
    private String name;
    private String nameOfCreator;
    private ArrayList<Audio> playList;

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public String getNameOfCreator() {
        return nameOfCreator;
    }

    public ArrayList<Audio> getPlayList() {
        return playList;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNameOfCreator(String nameOfCreator) {
        this.nameOfCreator = nameOfCreator;
    }

    public void setPlayList(ArrayList<Audio> playList) {
        this.playList = playList;
    }
    @Override
    public String toString() {
        return "PlayList{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", nameOfCreator='" + nameOfCreator + '\'' +
                ", playList=" + playList +
                '}';
    }
}
