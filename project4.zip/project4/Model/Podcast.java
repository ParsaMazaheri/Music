package Model;

import java.time.LocalDate;

public class Podcast extends Audio{
    String caption;
    public Podcast(String model, String title,Genre genre,String lyric ,String link, String cover , int id){
        super(model,title,genre,lyric,link,cover,id);
        this.caption = caption;
    }
    @Override
    public Genre getGenre() {
        return super.getGenre();
    }

    @Override
    public int getNumberOfLikes() {
        return super.getNumberOfLikes();
    }

    @Override
    public int getNumberOfPlays() {
        return super.getNumberOfPlays();
    }

    public String getCaption() {
        return caption;
    }

    @Override
    public void setLink(String link) {
        super.setLink(link);
    }

    @Override
    public void setNumberOfLike(int numberOfLike) {
        super.setNumberOfLike(numberOfLike);
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    @Override
    public void setCover(String cover) {
        super.setCover(cover);
    }

    @Override
    public void setGenre(Genre genre) {
        super.setGenre(genre);
    }

    @Override
    public void setTitle(String title) {
        super.setTitle(title);
    }

    @Override
    public void setId(int id) {
        super.setId(id);
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public String toString() {
        return "Podcast{" +
                "caption='" + caption + '\'' +
                '}';
    }
}
