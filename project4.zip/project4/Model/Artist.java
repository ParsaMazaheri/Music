package Model;

import java.util.ArrayList;

public class Artist extends User{
    private double inCome;
    private ArrayList<User> following;
    private int numberOfFollowing = 0;
    private int numberOfPlays = 0;
    private int numberOflikes = 0;

    private String bio;
    public Artist(String userName, String password, String name, String email, int phoneNumber, int year, int month, int day) {
        super(userName, password, name, email, phoneNumber, year, month, day);

    }

    public int getNumberOflikes() {
        return numberOflikes;
    }

    public void setNumberOflikes(int numberOflikes) {
        this.numberOflikes = numberOflikes;
    }

    public void setNumberOfFollowing(int numberOfFollowing) {
        this.numberOfFollowing = numberOfFollowing;
    }

    public int getNumberOfPlays() {
        return numberOfPlays;
    }

    public double getInCome() {
        return inCome;
    }

    public void setNumberOfPlays(int numberOfPlays) {
        this.numberOfPlays = numberOfPlays;
    }

    public int getNumberOfFollowing() {
        return numberOfFollowing;
    }


    @Override
    public String getRole() {
        return super.getRole();
    }

    @Override
    public String getUserName() {
        return super.getUserName();
    }

    public ArrayList<User> getFollowing() {
        return following;
    }

    public String getBio() {
        return bio;
    }

    @Override
    public String getName() {
        return super.getName();
    }


    @Override
    public String getEmail() {
        return super.getEmail();
    }

    @Override
    public void setPassword(String password) {
        super.setPassword(password);
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    @Override
    public void setRole(String role) {
        super.setRole(role);
    }

    public void setFollowing(ArrayList<User> following) {
        this.following = following;
    }

    public void setInCome(double inCome) {
        this.inCome = inCome;
    }

    @Override
    public int getPhoneNumber() {
        return super.getPhoneNumber();
    }
    @Override
    public String toString() {
        return "Artist{" +
                "inCome=" + inCome +
                ", following=" + following +
                ", bio='" + bio + '\'' +
                '}';
    }
}
