package Model;

public enum TypesOfListeners {
    Ordinarylistener,
    Premiumlistener;

}
