package Model;
import java.util.AbstractList;
import java.util.ArrayList;

public class Album {
   private int id;
   private String name;
   private String artistName;
   private ArrayList<Music> musicList;

    public int getId() {
        return id;
    }

    public String getArtistName() {
        return artistName;
    }

    public ArrayList<Music> getMusicList() {
        return musicList;
    }
    public String getName() {
        return name;
    }

    public void setArtistName(String artistName) {
        this.artistName = artistName;
    }

    public void setMusicList(ArrayList<Music> musicList) {
        this.musicList = musicList;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Album{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", artistName='" + artistName + '\'' +
                ", musicList=" + musicList +
                '}';
    }
}
