package Model;
import java.time.LocalDate;
import java.time.Month;

public class Audio {
    private int id;
    private String name;
    private String artistName;
    private String title;
    private int numberOfPlays = 0;
    private int numberOfLikes = 0;
    private LocalDate releaseDate;
    private String link;
    private String cover;
    private Genre genre;
    private String lyric;
   private String model;



    public Audio(String model, String title,Genre genre,String lyric ,String link, String cover , int id) {
        this.id = id;
        this.lyric = lyric;
        this.title = title;
        this.model = model;
        this.genre = genre;
        this.link = link;
        this.cover = cover;
    }
    public int getId(){return id;}
    public String getName(){return name;}
    public String getArtistName(){return artistName;}
    public int getNumberOfPlays(){return numberOfPlays;}
    public int getNumberOfLikes(){return numberOfLikes;}
    public LocalDate getReleaseDate(){return releaseDate;}
    public int getYear(){return releaseDate.getYear();}
    public Month getMonth(){return releaseDate.getMonth();}
    public int getDay(){return releaseDate.getDayOfMonth();}
    public Genre getGenre(){return genre;}
    public String getLink(){return link;};
    public void setLink(String link) {this.link = link;}
    public String getCover() {return cover;}
    public String getTitle() {return title;}
    public void setId(int id) {this.id = id;}
    public void setName(String name) {this.name = name;}
    public void setNumberOfPlays(int numberOfPlays) {this.numberOfPlays = numberOfPlays;}
    public void setNumberOfLike(int numberOfLike) {this.numberOfLikes = numberOfLike;}
    public void setReleaseDate(LocalDate releaseDate) {this.releaseDate = releaseDate;}
    public void setGenre(Genre genre) {this.genre = genre;}
    public void setCover(String cover) {this.cover = cover;}
    public void setTitle(String title) {this.title = title;}

    public String getLyric() {
        return lyric;
    }

    public void setLyric(String lyric) {
        this.lyric = lyric;
    }

    @Override
    public String toString() {
        return "Audio{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", artistName='" + artistName + '\'' +
                ", link='" + link + '\'' +
                ", cover='" + cover + '\'' +
                ", genre=" + genre +
                ", lyric='" + lyric + '\'' +
                ", model='" + model + '\'' +
                '}';
    }
}
