package Model;

import java.util.ArrayList;

public class Singer extends Artist{
    ArrayList<Album> albums;
    public Singer(String userName, String passWord, String name, String email, int phoneNumber, int year, int month, int day) {
        super(userName, passWord,name, email, phoneNumber, year, month, day);
    }
}
