package Model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DataBase {
   private ArrayList<User> users;
   private ArrayList<Audio> audios;
   private ArrayList<Report> reports;
   private ArrayList<Artist>Artists;
   private ArrayList<Admin>admin;
    DataBase() {
        this.users = new ArrayList<User>();
        this.audios = new ArrayList<Audio>();
        this.reports = new ArrayList<Report>();
        this.Artists = new ArrayList<Artist>();
        this.admin = new ArrayList<Admin>();
    }

    public ArrayList<Artist> getArtists() {
        return Artists;
    }

    public ArrayList<Audio> getAudios() {
        return audios;
    }

    public ArrayList<Report> getReports() {
        return reports;
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public void setArtists(ArrayList<Artist> artists) {
        Artists = artists;
    }

    public void setAudios(ArrayList<Audio> audios) {
        this.audios = audios;
    }

    public void setReports(ArrayList<Report> reports) {
        this.reports = reports;
    }

    public void setUsers(ArrayList<User> users) {
        this.users = users;
    }

    public ArrayList<Admin> getAdmin() {
        return admin;
    }

    public void setAdmin(ArrayList<Admin> admin) {
        this.admin = admin;
    }

    public void sortAudiosByLikes() {
        Collections.sort(audios, new Comparator<Audio>() {
            public int compare(Audio audio1, Audio audio2) {
                return audio2.getNumberOfLikes() - audio1.getNumberOfLikes();
            }
        });
    }
    public void sortAudiosByPlays() {
        Collections.sort(audios, new Comparator<Audio>() {
            public int compare(Audio audio1, Audio audio2) {
                return audio2.getNumberOfPlays() - audio1.getNumberOfPlays();
            }
        });
    }

    public User getUserByUserName(String username) {
        for (User user : users) {
            if (user.getUserName().equals(username))
                return user;
        }
        return null;
    }
    public Audio getAudioById(int audioId){
        for (Audio audio1 : audios){
            if (audio1.getId()==audioId){
                return audio1;
            }
        }
        return null;
    }
    public ArrayList<Artist> getArtist(){
        ArrayList<Artist> resalt = new ArrayList<>();
        for (User user : users){
            if (user instanceof Artist){
                resalt.add((Artist)user);
            }
        }
        return resalt;
    }
    public String getArtistByUserName(String username) {
        for (User user : users) {
            if (user instanceof Artist)
                if (user.getUserName().equals(username)) {
                    return user.getName();
                }
        }
        return null;
    }
}
