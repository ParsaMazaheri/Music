package Model;

public class Report {
   private String reportingUser;
   private String reportedArtist;
    private String explained;

    public String getExplained() {
        return explained;
    }

    public String getReportedArtist() {
        return reportedArtist;
    }

    public String getReportingUser() {
        return reportingUser;
    }

    public void setReportedArtist(String reportedArtist) {
        this.reportedArtist = reportedArtist;
    }

    public void setExplained(String explained) {
        this.explained = explained;
    }

    public void setReportingUser(String reportingUser) {
        this.reportingUser = reportingUser;
    }
}
