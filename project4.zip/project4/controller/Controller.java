package controller;
import Model.*;

import java.util.ArrayList;
import java.util.Scanner;

public class Controller {
    enum Genres {
        Rock,
        Pop,
        Jazz,
        HipHop,
        Country,
        True_Crime,
        Society,
        Interview,
        History;
    }
    Music music;

    Scanner sc = new Scanner(System.in);
    User loginUser = null;
    DataBase dataBase ;
    Listener loginListener = null;
    Artist loginArtist = null;
    ArrayList<Artist> FollowArtist = new ArrayList<Artist>();
    ArrayList<Artist> userList = new ArrayList<Artist>();
    ArrayList<Audio> audioList = new ArrayList<Audio>();
    PlayList playList;
   public void Singup() {
        String role = sc.next();
        String userName = sc.next();
        String password = sc.next();
        String name = sc.next();
        String email = sc.next();
        int phoneNumber = sc.nextInt();
        int year = sc.nextInt();
        int month = sc.nextInt();
        int day = sc.nextInt();
        if (role.equals("L")) {
            Listener listener = new Listener(userName, password,name, email, phoneNumber, year, month, day);

        }
        if (role.equals("p")) {
            Podcaster podcaster = new Podcaster(userName, password, name, email, phoneNumber, year, month, day);
            String bio = sc.nextLine();
            podcaster.setBio(bio);
        }
        if (role.equals("s")) {
            Singer singer = new Singer(userName, password, name, email, phoneNumber, year, month, day);
            String bio = sc.nextLine();
            singer.setBio(bio);
        }
    }
   public String FavouriteGenres(){
        String[] favouriteGenres = new String[3];
        for (int i = 0 ; i<4;i++){
            String answer = sc.nextLine();
            favouriteGenres[i] = answer;
            return favouriteGenres[i];
        }
        return null;
    }
    public void LogIn() {
        String userName = sc.next();
        String password = sc.next();
        User user = dataBase.getUserByUserName(userName);
        if (user.getUserName().equals(userName) && user.getPassWord().equals(password)) {
            if (user instanceof Listener) {
                loginUser = (Listener) user;
            }
        }
    }
    public void logout(){
        return;
    }
    public StringBuilder AccountInfo(){
        StringBuilder x = new StringBuilder();
        x.append(loginUser.toString());
        return x;
    }
    public StringBuilder Followers(){
        StringBuilder answer = new StringBuilder();
        answer.append(loginArtist.getFollowing());
        return answer;
    }
    public StringBuilder ViewsStatistics(){
        dataBase.sortAudiosByLikes();
        StringBuilder answer = new StringBuilder();
        for (Audio audio : dataBase.getAudios()){
            answer.append(audio.getName() + audio.getNumberOfPlays());
            return answer;
        }
        return null;
    }
    public double CalculateEarnings(){
        if (loginArtist instanceof Singer){
            double income = loginArtist.getNumberOfPlays() * 0.4;
            loginArtist.setInCome(income);
            return  loginArtist.getInCome();
        }
        else {
            double income = loginArtist.getNumberOfPlays() * 0.5;
            loginArtist.setInCome(income);
            return  loginArtist.getInCome();
        }
    }
    public void NewAlbum(){
        Album album = new Album();
        String name = sc.next();
        album.setName(name);
    }
    public void Publish(){
        String model = sc.next();
        String title = sc.next();
        Genre genre = Genre.HipHop ;
        String lyric = sc.next();
        String link = sc.next();
        String cover = sc.next();
        int id = sc.nextInt();
        Audio audio = new Audio(model,title,genre,lyric,link,cover,id);
        audio.setName(title);

    }
    Audio audio;
    Artist artist;
    public StringBuilder Statistics(){
        StringBuilder answer = new StringBuilder();
        for (Audio audio : dataBase.getAudios()) {
            answer.append(audio.getId() + " " + audio.getName() + " " + audio.getNumberOfLikes() + "\n");
        }
        return answer;
    }
    public StringBuilder Audios(){
        StringBuilder answer = new StringBuilder();
        for(int i = 0 ; i< audio.getName().toCharArray().length;i++){
            answer.append(dataBase.getAudios());
        }
        return answer;
    }
    public StringBuilder Audio(){
        int answer = sc.nextInt();
        StringBuilder answer2 = new StringBuilder();
        if (audio.getId() == answer){
            return answer2.append(audio.toString());
        }
        return null;
    }
    public StringBuilder Artist(){
        String answer = sc.next();
        StringBuilder answer2 = new StringBuilder();
        if(artist.getUserName() == answer){
            return answer2.append(artist.toString());
        }
        return null;
    }
    public StringBuilder Reports(){
        StringBuilder answer2 = new StringBuilder();
        return answer2.append(dataBase.getReports());
    }
    public void GetSuggestions() {
        ArrayList<Genre> favoriteGenres = loginListener.getFavoriteGenres();
        ArrayList<Audio> suggest = new ArrayList<>();
        for (Audio audio : dataBase.getAudios()) {
            if (favoriteGenres.contains(audio.getGenre())) {
                suggest.add(audio);
            }
        }
        for (int i = 0; i < suggest.size(); i++) {
            if (i <= 10) {
                Audio audio = suggest.get(i);
                StringBuilder a = new StringBuilder();
                a.append(audio.getName() + " - " + audio.getArtistName() + " - " + audio.getGenre());
            }
            else if (i > 11) {
                break;
            }
        }
    }

    public StringBuilder Artists() {
        for (User user : dataBase.getArtist()) {
            System.out.println(user.getName());
            StringBuilder answer = new StringBuilder();
            answer.append(user.getName());
            return answer.append(user.getName());

        }
        return null;
    }

    public StringBuilder ArtistInformation() {//2-1
        String v = sc.nextLine();
        for (Artist artist : dataBase.getArtists()) {
            if (artist.getUserName().equals(v)) {
                StringBuilder answer = new StringBuilder();
                answer.append(artist.getName() + artist.getFollowing() + artist.getEmail() + artist.getBio());
                return answer;
            }
        }
        return null;
    }

    public void Follow() {
        String userName = sc.next();
        if(dataBase.getArtistByUserName(userName).equals(userName)){
            loginListener.setGenres(dataBase.getArtistByUserName(userName));
            loginArtist.setNumberOfFollowing(1);
        }
    }

    public String Search() {
        String search = sc.next();
        for (User user : dataBase.getUsers()) {
            if (user instanceof Artist) {
                Artist artist = (Artist) user;
                if (artist.getName().contains(search) || artist.getUserName().contains(search)) {
                    userList.add(artist);
                    return artist.getName();
                }
            }
        }
        for (Audio audio : dataBase.getAudios()) {
            if (audio.getTitle().contains(search)) {
                audioList.add(audio);
                return audio.getName();
            }
        }
        return null;
    }

    public void Sort() {
        String answer = sc.next();
        if (answer == "L") {
            dataBase.sortAudiosByLikes();
        }
        else if(answer == "P") {
            dataBase.sortAudiosByPlays();
        }
    }
    public StringBuilder Filter() {
        String p = sc.next();
        if (p == "A") {
            for (int i = 0; i < dataBase.getArtists().size(); i++) {
                if (dataBase.getArtists().get(i) instanceof Artist) {
                    StringBuilder answer = new StringBuilder();
                    answer.append(dataBase.getAudios());
                    return answer;
                }
            }
        }
        if (p == "G") {
            Genre genre  = Genre.HipHop;
            for (int i = 0; i < dataBase.getAudios().size(); i++) {
                if (dataBase.getAudios().get(i).getGenre() == genre) {
                    StringBuilder answer = new StringBuilder();
                    return answer.append(dataBase.getAudios());
                }
            }
        }
        return null;
    }
    public void add() {
        String playlistName = sc.next();
        int audioId = sc.nextInt();
        if (playList.getName().equals(playlistName)) {
            Audio audio = dataBase.getAudioById(audioId);
            if (audio != null) {
                playList.setNameOfCreator(playlistName);
            }
        }
    }
    Report report;
    public StringBuilder ShowPlaylists(){
        StringBuilder answer = new StringBuilder();
        return answer.append(loginListener.getPlayLists());
    }
    public void Play(){
        int answer = sc.nextInt();
        if(audioList.equals(answer)){
            int i = 0;
            loginArtist.setNumberOfPlays(++i);
        }
    }
    public void likeAudio() {
        int answer = sc.nextInt();
        if(audioList.equals(answer)){
            int i = 0;
            loginArtist.setNumberOflikes(++i);
        }
    }
    public void showLyrics() {
        int answer = sc.nextInt();
        if(music.equals(answer)){
            music.getLyric();
        }
    }
    public void ReportArtist(){
        String username = sc.next();
        String explanation = sc.next();
    }
    public StringBuilder showFollowings() {
        StringBuilder answer = new StringBuilder();
        for (Artist artist : loginListener.getFollowed()) {
            answer.append(artist.getUserName());
            return answer.append(artist.getUserName());
        }
        return null;
    }
    public StringBuilder GetPremium(){
        int answer = sc.nextInt();
        StringBuilder walletAndNumberOfDaysLeft = new StringBuilder();
        if (answer == 1){
            if (loginListener.getWallet()>=4){
                loginListener.wallet-=4;
                loginListener.numberOfDaysLeft+=30;
                return walletAndNumberOfDaysLeft.append("wallet:" + loginListener.wallet + "numberOfDaysLeft :" + loginListener.getNumberOfDaysLeft());
            }
        }
        else if(answer==2){
            if (loginListener.wallet>=9){
                loginListener.wallet-=9;
                loginListener.numberOfDaysLeft+=60;
                return walletAndNumberOfDaysLeft.append("wallet:" + loginListener.wallet + "numberOfDaysLeft :" + loginListener.getNumberOfDaysLeft());

            }
        }
        else if(answer==3){
            if (loginListener.wallet>=14){
                loginListener.wallet-=14;
                loginListener.numberOfDaysLeft+=180;
                return walletAndNumberOfDaysLeft.append("wallet:" + loginListener.wallet + "numberOfDaysLeft :" + loginListener.getNumberOfDaysLeft());

            }
        }
        return null;
    }

}


