package controller;
import Model.*;
import java.util.ArrayList;

public class LestenerConteoller extends Controller {
    public void GetSuggestions() {
        ArrayList<Genre> favoriteGenres = loginListener.getFavoriteGenres();
        ArrayList<Audio> suggest = new ArrayList<>();
        for (Audio audio : dataBase.getAudios()) {
            if (favoriteGenres.contains(audio.getGenre())) {
                suggest.add(audio);
            }
        }
        for (int i = 0; i < suggest.size(); i++) {
            if (i <= 10) {
                Audio audio = suggest.get(i);
                StringBuilder a = new StringBuilder();
                a.append(audio.getName() + " - " + audio.getArtistName() + " - " + audio.getGenre());
            }
            else if (i > 11) {
                break;
            }
        }
    }

   public StringBuilder Artists() {
        for (User user : dataBase.getArtist()) {
            System.out.println(user.getName());
            StringBuilder answer = new StringBuilder();
            answer.append(user.getName());
            return answer.append(user.getName());

        }
        return null;
    }

   public StringBuilder ArtistInformation() {//2-1
        String v = sc.nextLine();
        for (Artist artist : dataBase.getArtists()) {
            if (artist.getUserName().equals(v)) {
                StringBuilder answer = new StringBuilder();
                answer.append(artist.getName() + artist.getFollowing() + artist.getEmail() + artist.getBio());
                return answer;
            }
        }
        return null;
    }

   public void Follow() {
        String userName = sc.next();
        if(dataBase.getArtistByUserName(userName).equals(userName)){
            loginListener.setGenres(dataBase.getArtistByUserName(userName));
            loginArtist.setNumberOfFollowing(1);
        }
    }

   public String Search() {
        String search = sc.next();
        for (User user : dataBase.getUsers()) {
            if (user instanceof Artist) {
                Artist artist = (Artist) user;
                if (artist.getName().contains(search) || artist.getUserName().contains(search)) {
                    userList.add(artist);
                    return artist.getName();
                }
            }
        }
        for (Audio audio : dataBase.getAudios()) {
            if (audio.getTitle().contains(search)) {
                audioList.add(audio);
                return audio.getName();
            }
        }
        return null;
    }

   public void Sort() {
        String answer = sc.next();
        if (answer == "L") {
            dataBase.sortAudiosByLikes();
        }
        else if(answer == "P") {
            dataBase.sortAudiosByPlays();
        }
    }
   public StringBuilder Filter() {
        String p = sc.next();
        if (p == "A") {
            for (int i = 0; i < dataBase.getArtists().size(); i++) {
                if (dataBase.getArtists().get(i) instanceof Artist) {
                    StringBuilder answer = new StringBuilder();
                    answer.append(dataBase.getAudios());
                    return answer;
                }
            }
        }
        if (p == "G") {
            Genre genre  = Genre.HipHop;
                for (int i = 0; i < dataBase.getAudios().size(); i++) {
                    if (dataBase.getAudios().get(i).getGenre() == genre) {
                        StringBuilder answer = new StringBuilder();
                       return answer.append(dataBase.getAudios());
                    }
                }
            }
        return null;
        }
   public void add() {
        String playlistName = sc.next();
        int audioId = sc.nextInt();
        if (playList.getName().equals(playlistName)) {
                Audio audio = dataBase.getAudioById(audioId);
                if (audio != null) {
                    playList.setNameOfCreator(playlistName);
                }
        }
    }

    }
