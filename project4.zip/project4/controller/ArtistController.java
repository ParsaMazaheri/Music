package controller;
import Model.*;

import java.util.Date;

public class ArtistController extends Controller{
   public StringBuilder Followers(){
        StringBuilder answer = new StringBuilder();
        answer.append(loginArtist.getFollowing());
        return answer;
    }
   public StringBuilder ViewsStatistics(){
        dataBase.sortAudiosByLikes();
        StringBuilder answer = new StringBuilder();
        for (Audio audio : dataBase.getAudios()){
            answer.append(audio.getName() + audio.getNumberOfPlays());
            return answer;
        }
        return null;
    }
   public double CalculateEarnings(){
        if (loginArtist instanceof Singer){
            double income = loginArtist.getNumberOfPlays() * 0.4;
            loginArtist.setInCome(income);
            return  loginArtist.getInCome();
        }
        else {
            double income = loginArtist.getNumberOfPlays() * 0.5;
            loginArtist.setInCome(income);
            return  loginArtist.getInCome();
        }
    }
   public void NewAlbum(){
        Album album = new Album();
        String name = sc.next();
        album.setName(name);
    }
   public void Publish(){
        String model = sc.next();
        String title = sc.next();
        Genre genre = Genre.HipHop ;
        String lyric = sc.next();
        String link = sc.next();
        String cover = sc.next();
        int id = sc.nextInt();
         Audio audio = new Audio(model,title,genre,lyric,link,cover,id);
         audio.setName(title);

    }
}

