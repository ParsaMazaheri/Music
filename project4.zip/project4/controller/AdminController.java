package controller;

import Model.Artist;
import Model.Audio;
import Model.DataBase;

public class AdminController extends Controller{
    DataBase dataBase;
    Audio audio;
    Artist artist;
   public StringBuilder Statistics(){
        StringBuilder answer = new StringBuilder();
        for (Audio audio : dataBase.getAudios()) {
            answer.append(audio.getId() + " " + audio.getName() + " " + audio.getNumberOfLikes() + "\n");
        }
        return answer;
    }
    public StringBuilder Audios(){
        StringBuilder answer = new StringBuilder();
        for(int i = 0 ; i< audio.getName().toCharArray().length;i++){
            answer.append(dataBase.getAudios());
        }
        return answer;
    }
   public StringBuilder Audio(){
        int answer = sc.nextInt();
       StringBuilder answer2 = new StringBuilder();
       if (audio.getId() == answer){
            return answer2.append(audio.toString());
        }
       return null;
    }
    public StringBuilder Artist(){
        String answer = sc.next();
        StringBuilder answer2 = new StringBuilder();
        if(artist.getUserName() == answer){
           return answer2.append(artist.toString());
        }
        return null;
    }
   public StringBuilder Reports(){
       StringBuilder answer2 = new StringBuilder();
       return answer2.append(dataBase.getReports());
    }
}
