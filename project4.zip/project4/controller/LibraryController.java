package controller;
import Model.*;

public class LibraryController extends Controller{
    Report report;
    public StringBuilder ShowPlaylists(){
        StringBuilder answer = new StringBuilder();
        return answer.append(loginListener.getPlayLists());
    }
    public void Play(){
        int answer = sc.nextInt();
        if(audioList.equals(answer)){
            int i = 0;
            loginArtist.setNumberOfPlays(++i);
        }
    }
   public void likeAudio() {
        int answer = sc.nextInt();
        if(audioList.equals(answer)){
            int i = 0;
            loginArtist.setNumberOflikes(++i);
        }
    }
    public void showLyrics() {
        int answer = sc.nextInt();
        if(music.equals(answer)){
            music.getLyric();
        }
    }
   public void ReportArtist(){
        String username = sc.next();
        String explanation = sc.next();
    }
    public StringBuilder showFollowings() {
        StringBuilder answer = new StringBuilder();
        for (Artist artist : loginListener.getFollowed()) {
            answer.append(artist.getUserName());
            return answer.append(artist.getUserName());
        }
        return null;
    }
    public StringBuilder GetPremium(){
        int answer = sc.nextInt();
        StringBuilder walletAndNumberOfDaysLeft = new StringBuilder();
        if (answer == 1){
            if (loginListener.getWallet()>=4){
                loginListener.wallet-=4;
                loginListener.numberOfDaysLeft+=30;
                return walletAndNumberOfDaysLeft.append("wallet:" + loginListener.wallet + "numberOfDaysLeft :" + loginListener.getNumberOfDaysLeft());
            }
        }
        else if(answer==2){
            if (loginListener.wallet>=9){
                loginListener.wallet-=9;
                loginListener.numberOfDaysLeft+=60;
                return walletAndNumberOfDaysLeft.append("wallet:" + loginListener.wallet + "numberOfDaysLeft :" + loginListener.getNumberOfDaysLeft());

            }
        }
        else if(answer==3){
            if (loginListener.wallet>=14){
                loginListener.wallet-=14;
                loginListener.numberOfDaysLeft+=180;
                return walletAndNumberOfDaysLeft.append("wallet:" + loginListener.wallet + "numberOfDaysLeft :" + loginListener.getNumberOfDaysLeft());

            }
        }
        return null;
    }
}
