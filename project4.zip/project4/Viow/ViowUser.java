package Viow;
import Model.Listener;
import controller.Controller;
import controller.*;
import controller.LibraryController;
import java.util.Scanner;
public class ViowUser {
        private Controller controller;
        Scanner sc = new Scanner(System.in);
        public void run() {
            Scanner sc = new Scanner(System.in);
            boolean running = true;

            while (running) {
                System.out.println("1. Signup");
                System.out.println("2. FavouriteGenres ");
                System.out.println("3. Login");
                System.out.println("4. Logout");
                System.out.println("5. Account Info");
                System.out.println("6. Get Suggestions");
                System.out.println("7. Show Artists");
                System.out.println("8. Artist Information");
                System.out.println("9. Follow Artist");
                System.out.println("10. Search");
                System.out.println("11. Sort");
                System.out.println("12. Filter");
                System.out.println("13. Add to Playlist");
                System.out.println("14. Show Playlists");
                System.out.println("15. Play");
                System.out.println("16. Like Audio");
                System.out.println("17. Show Lyrics");
                System.out.println("18. Show Followings");
                System.out.println("19. Report Artist");
                System.out.println("20. Get Premium");
                System.out.println("21. Statistics");
                System.out.println("22. Show Audios");
                System.out.println("23. Show Audio");
                System.out.println("24. Show Artists");
                System.out.println("25. Show Artist");
                System.out.println("26. Show Reports");
                System.out.println("27. Show Followers");
                System.out.println("28. Show Views Statistics");
                System.out.println("29. Calculate Earnings");
                System.out.println("30. New Album");
                System.out.println("31. Publish");
                System.out.print("0. Exit ");
                System.out.print("Enter your choice: ");
                int choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        controller.Singup();
                        break;
                    case 2:
                        controller.FavouriteGenres();
                        break;
                    case 3:
                        controller.LogIn();
                        break;
                    case 4:
                        controller.logout();
                        break;
                    case 5:
                        controller.AccountInfo();
                        break;
                    case 6:
                        controller.GetSuggestions();
                        break;
                    case 7:
                        controller.Artists();
                        break;
                    case 8:
                        controller.ArtistInformation();
                        break;
                    case 9:
                        controller.Follow();
                        break;
                    case 10:
                        controller.Search();
                        break;
                    case 11:
                        controller.Sort();
                        break;
                    case 12:
                        controller.Filter();
                        break;
                    case 13:
                        controller.ShowPlaylists();
                        break;
                    case 14:
                        controller.add();
                        break;
                    case 15:
                        controller.Play();
                        break;
                    case 16:
                        controller.likeAudio();
                        break;
                    case 17:
                        controller.showLyrics();
                        break;
                    case 18:
                        controller.showFollowings();
                        break;
                    case 19:
                        controller.ReportArtist();
                        break;
                    case 20:
                        controller.GetPremium();
                        break;
                    case 21:
                        controller.Statistics();
                        break;
                    case 22:
                        controller.Audios();
                        break;
                    case 23:
                        controller.Audio();
                        break;
                    case 24:
                        controller.Artists();
                        break;
                    case 25:
                        controller.Artist();
                        break;
                    case 26:
                        controller.Reports();
                        break;
                    case 27:
                        controller.showFollowings();
                        break;
                    case 28:
                        controller.ViewsStatistics();
                        break;
                    case 29:
                        controller.CalculateEarnings();
                        break;
                    case 0:
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
            sc.close();
        }
}
