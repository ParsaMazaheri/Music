import Viow.*;
import controller.*;
import Model.*;
public class Main {
    public static void main(String[] args) {
        ViowUser v = new ViowUser();
        v.run();
    }

}